<div class="option-bar large">
	<label for="select-guests"><?php echo esc_html__( 'No of Guests', 'framework' ); ?></label>
	<span class="selectwrap">
		<select name="guests" id="select-guests" class="search-select"><?php inspiry_min_guests(); ?></select>
	</span>
</div>