<?php
/**
 * Taxonomy: Property Type
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/taxonomy/property-type' );
