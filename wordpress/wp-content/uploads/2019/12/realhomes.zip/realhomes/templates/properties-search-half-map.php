<?php
/**
 * Template Name: Properties Search Half Map
 *
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/page/search-half-map' );
